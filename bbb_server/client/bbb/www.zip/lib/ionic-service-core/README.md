ionic-service-common
====================

Common required service tools and addons
