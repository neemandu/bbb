app
.controller('GroupsCtrl', function($scope, $ionicPopover, Group) {
	$scope.group = Group;
	$scope.groups = $scope.group.find({});
  // .fromTemplateUrl() method
  $ionicPopover.fromTemplateUrl('templates/addGroupPopover.html', {
    scope: $scope
  }).then(function(popover) {
    $scope.popover = popover;
  });

  

})